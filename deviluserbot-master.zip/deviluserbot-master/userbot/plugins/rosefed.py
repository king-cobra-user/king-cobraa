import datetime
import asyncio
from telethon import events
from telethon.errors.rpcerrorlist import YouBlockedUserError, UserAlreadyParticipantError
from telethon.tl.functions.account import UpdateNotifySettingsRequest
from telethon.tl.functions.messages import ImportChatInviteRequest
from userbot.utils import admin_cmd
import time
from userbot import ALIVE_NAME
from userbot import CMD_HELP
from userbot.cmdhelp import CmdHelp

naam = str(ALIVE_NAME)

bot = "@Missrose_bot"

@borg.on(admin_cmd("createfed ?(.*)"))
async def _(event):
    if event.fwd_from:
        return    
    sysarg = event.pattern_match.group(1)
    if sysarg == "":
      async with borg.conversation(bot) as conv:
          try:
              await conv.send_message("/start")
              response = await conv.get_response()
              await conv.send_message("/newfed Devil Federation")
              audio = await conv.get_response()
              final = ("If you would like to know more about ROSE BOT federation, please visit @Missrose_bot." , "")
              await borg.send_message(event.chat_id, audio.text)
              await event.delete()
          except YouBlockedUserError:
              await event.edit("**Error:** unblock @Missrose_bot `and retry!")

CmdHelp("fed").add_command(
  'newfed', 'make new fed via a rose'
).add()
